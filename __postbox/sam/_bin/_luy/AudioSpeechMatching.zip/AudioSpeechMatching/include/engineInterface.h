#ifndef _INTERFACE_H_
#define _INTERFACE_H_

#define	MATCHING_BEST		0
#define	MATCHING_GOOD		1
#define MATCHING_BAD		2


#ifdef __cplusplus
extern "C"
{
#endif
	
	int getMatchingResult(short* benchBuf, int benchLength, short* sampleBuf, int sampleLength);
	int makeTrainData(char* dirName);
	int testData(char* dirName);

#ifdef __cplusplus
}
#endif

#endif
