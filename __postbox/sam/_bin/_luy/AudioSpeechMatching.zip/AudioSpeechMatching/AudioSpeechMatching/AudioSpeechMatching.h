#ifndef _AUDIO_SPEECH_MATCH_H_
#define _AUDIO_SPEECH_MATCH_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "sndfile.h"


////    define macro and constant values    ////
#define FS 16000
#define MAX_INT16 0x3FFF

#define _BENCH	0
#define _SAMPLE	1

#define CMD_MATCHING	0
#define CMD_TRAIN		1
#define CMD_TEST		2
#define CMD_ERROR		3

////    define global variables    ////
short *g_streamBenchBuffer;
short *g_streamSampleBuffer;

int readWavFile(char* inFileName, int flag);
sf_count_t getFrameCount(char *wavname);

void matchingProcess(char* benchWavName, char* sampleWavName);
void trainingData(char* dirName);
void testAccuracy(char* dirName);

#endif
