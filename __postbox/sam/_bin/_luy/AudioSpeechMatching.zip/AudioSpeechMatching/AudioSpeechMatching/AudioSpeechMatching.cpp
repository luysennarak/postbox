// AudioSpeechMatching.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "engineInterface.h"
#include "AudioSpeechMatching.h"


void ReportUsage(void)
{	
	printf("\nUSAGE: AudioSpeechMatching [options] [wave file   wave file]  \n\n");
	printf(" Option                                                         \n\n");
	printf(" wave1 wave2      output matching result of wave1 and wave2     \n");
	printf("\n\n");
	printf(" -test  dir       dir to test matching                          \n");
	printf(" -train dir       set directory including wave files to train   \n\n");
	printf("\n\n");
}

int parse_cmd_ln(int cmdNum, char *cmds[])
{
	if (cmdNum < 3) {
		ReportUsage();
		return CMD_ERROR;
	}
	if (strcmp(cmds[1], "-test") == 0) {
		if (cmdNum < 3) {
			ReportUsage();
			return CMD_ERROR;
		}
		return CMD_TEST;
	}

	if (strcmp(cmds[1], "-train") == 0) {
		if (cmdNum < 3) {
			ReportUsage();
			return CMD_ERROR;
		}
		return CMD_TRAIN;
	}
	return CMD_MATCHING;
}

int main(int argc, char* argv[])
{
	int nFlag = parse_cmd_ln(argc, argv);
	switch (nFlag)
	{
	case CMD_MATCHING:
		matchingProcess(argv[1], argv[2]);
		break;
	case CMD_TRAIN:
		trainingData(argv[2]);
		break;
	case CMD_TEST:
		testAccuracy(argv[2]);
		break;
	default:
		break;
	}		

    return 0;
}

void matchingProcess(char* benchWavName, char* sampleWavName)
{
	printf("\n");

	int nBenchFrames, nSampleFrames;
	if ((nBenchFrames = readWavFile(benchWavName, _BENCH)) < 0)
		return;
	if ((nSampleFrames = readWavFile(sampleWavName, _SAMPLE)) < 0)
		return;

	int resScore = 0;
	resScore = getMatchingResult(g_streamBenchBuffer, nBenchFrames, g_streamSampleBuffer, nSampleFrames);
	
	if (g_streamBenchBuffer != NULL) free(g_streamBenchBuffer);
	if (g_streamSampleBuffer != NULL) free(g_streamSampleBuffer);
}

void trainingData(char* dirName)
{
	makeTrainData(dirName);

	char* cmd = (char*)malloc(256);
	strcpy(cmd, "svm-scale.exe -l 0 -u 1 -s SCALE SVM_data > SVM_NorData");
	system(cmd);

	strcpy(cmd, "svm-train.exe -s 4 -b 1 -g 2 -c 32768 SVM_NorData SVR"); // g 0.03125
	printf("%s\n", cmd);
	system(cmd);

	free(cmd);
}


void testAccuracy(char* dirName)
{
	system("del test_prob");
	system("del test_data");
	system("del test.predict");

	if (testData(dirName) < 0) {
		printf("Error occurs!\n");
		return;
	}

	// use svm-predict
	char* cmd = (char*)malloc(256);
	strcpy(cmd, "svm-scale.exe -r SCALE test_data > test_NorData");
	system(cmd);

	strcpy(cmd, "svm-predict.exe -b 1 test_NorData SVR test.predict");
	printf("\n%s\n", cmd);
	system(cmd);
	free(cmd);
}


int readWavFile(char* inFileName, int flag)
{
	SNDFILE	*infile = NULL;
	SF_INFO sfinfo;
	sf_count_t	count, i;

	if ((infile = sf_open(inFileName, SFM_READ, &sfinfo)) == NULL) {
		fprintf(stderr, "%s file cannot open.\n", inFileName);
		return -1;
	}

	if (sf_seek(infile, 0, SEEK_SET) < 0) {
		fprintf(stderr, "Error occurs in reading %s file!\n", inFileName);
		return -1;
	}
	if (sfinfo.samplerate != FS)
	{
		fprintf(stderr, "%s is not 16KHz.\n", inFileName);
		sf_close(infile);
		return -1;
	}
	count = sfinfo.frames;

	unsigned int nChannels = sfinfo.channels;
	float* m_buffer = (float*)malloc((size_t)count*nChannels*sizeof(float));
	short* results;

	if (flag == _BENCH) {
		if (g_streamBenchBuffer != NULL) free(g_streamBenchBuffer);
		g_streamBenchBuffer = (short*)malloc((size_t)count*sizeof(float));
		results = g_streamBenchBuffer;

		printf("Read standard wave file with %d samples.\n", (int)count);
	}
	else {
		if (g_streamSampleBuffer != NULL) free(g_streamSampleBuffer);
		g_streamSampleBuffer = (short*)malloc((size_t)count*sizeof(float));
		results = g_streamSampleBuffer;

		printf("Read test wave file with %d samples.\n", (int)count);
	}

	count = sf_readf_float(infile, m_buffer, sfinfo.frames);
	for (i = 0; i < count; ++i) {
		results[i] = (short)(MAX_INT16*m_buffer[i*nChannels]);  // select only first channel
	}	
	
	free(m_buffer);
	sf_close(infile);
	return (int)count;
}

sf_count_t getFrameCount(char *wavname)
{
	SNDFILE	*infile = NULL;
	SF_INFO sfinfo;

	sf_count_t	count;

	if ((infile = sf_open(wavname, SFM_READ, &sfinfo)) == NULL)
		return -1;
	count = sfinfo.frames;
	sf_close(infile);
	return count;
}