#include "define.h"
#include "util.h"
#include <math.h>
#include <stdio.h>

float getEucDist(float *x1, float *x2)
{
	int i;
	float sum = 0;
	for (i = 1; i < FEAT_NUM; i++)
		sum += (x1[i] - x2[i])*(x1[i] - x2[i]);
	return sqrtf(sum);
}

void getDistanceMatirx(float** distMat, float **Mat0, float **Mat1, int row0, int row1)
{
	int row, col;
	for (row = 0; row < row0; row++) {
		for (col = 0; col < row1; col++) {
			distMat[row][col] = getEucDist(Mat0[row], Mat1[col]);
		}
	}
}


// calculate Kurtosis
// Kurt = E[pow((X-mu)/sigma, 4)]
float getKurt(int* varData, int nLen)
{
	float mu, sigma;
	float kurt;
	int i, nSum = 0;
	float samp;
	// calculate mu (mean value)
	for (i = 0; i < nLen; i++)
		nSum += varData[i];
	mu = (float)nSum / nLen;

	// calculate sigma (standard deviation)
	sigma = 0; samp = 0;
	for (i = 0; i < nLen; i++)
		samp += ((float)varData[i] - mu)*((float)varData[i] - mu);
	if (nLen > 1)
		samp /= (float)(nLen - 1);
	sigma = sqrtf(samp);

	if (sigma == 0)
		return 0.0f;
	// get Kurt
	kurt = 0;
	for (i = 0; i < nLen; i++) {
		samp = ((float)varData[i] - mu) / sigma;
		kurt += powf(samp, 4);
	}
	kurt /= (float)nLen;

	return kurt;
}


void saveMat2File(float** matData, int nRow, int nCol, char* fname)
{

	FILE* fp = fopen(fname, "w");
	if (fp==NULL)
	{
		fprintf(stderr, "cannot open %s.\n", fname);
		return;
	}
	int i, j;
	for (i = 0; i < nRow; i++) {
		for (j = 0; j < nCol; j++) {
			if (j < nCol - 1)
				fprintf(fp, "%.2f,", matData[i][j]);
			else
				fprintf(fp, "%.2f\n", matData[i][j]);
		}
	}
	fclose(fp);

}