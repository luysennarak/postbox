
#ifndef _FEATURE_H_
#define _FEATURE_H_

#include "pocketsphinx.h"
#include "ps_alignment.h"
#include "state_align_search.h"
#include "pocketsphinx_internal.h"
#include "ps_search.h"
#include "sphinxbase/ckd_alloc.h"
#include "sphinxbase/yin.h"
#include "sphinxbase/err.h"
#include "sphinxbase/ad.h"
#include "sphinxbase/fe.h"

#include <math.h>

typedef struct _SVM_FEATURES {
	float yFeats[10];
	int pred_val;
} svm_feat;

typedef struct _SALIENCY
{
	float nInitial;
	float nFinal;
	float nMain;
	float nMainPos;
	float nMean;
	int pitchLevel;
} salience;

int		getFrameCount(char *wavname);
int		readWavFile(char* inFileName, short* wavBuffer);

// get acoustic feature - MFCC, 39 dimensions
int		get_mfcc_feat(mfcc_t **mfccMat, short *wavBuffer, int nFrame);

// get pitch feature
void	getpitch(int *pit, short *wavBuffer, int nSamples);
void	getPitchLevel(salience *ST);
int		getToneRythm(int pitchTone);

// VAD processing
float	removeNoise(short* sig, int nSamples, int* nStart, int* nEnd);
void	getEnergy(float* energy, short* sig, int nSamples);
float 	stZCR(short* frame, int nLen);

// DTW path
void	get_DTW_Path(float **distMat, int row0, int row1, int **path, int* len, int nMode);

// get SVM features for positive and negative
int		findFilesInDir(char* srtPath);
int		writeSVMdata(char* fname1, char* fname2, int nID);
int		getTestData(char* fname1, char* fname2, int nID);
int		getSVMFeatures(mfcc_t** mfc0, int row0, mfcc_t** mfc1, int row1, mfcc_t** mfc1_inv, int* pitch0, int* pitch1, svm_feat* stFeat);
int		getSVMFeatures_New(mfcc_t** mfc0, int row0, mfcc_t** mfc1, int row1, int* pitch0, int* pitch1, svm_feat* stFeat);
int		getLocalPitchFeatures(int *P0, int *P1, int row0, int row1);
int		getSvmPredict(mfcc_t** mfccMat0, int nLen0, mfcc_t** mfccMat1, int nLen1, int* pitch0, int* pitch1, int nID);


#endif