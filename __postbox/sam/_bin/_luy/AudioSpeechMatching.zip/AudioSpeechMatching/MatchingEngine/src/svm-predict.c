
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include "svm.h"


struct svm_node *x;
int max_nr_attr = 64;

struct svm_model* model;
int predict_probability=0;


int callPredict(float* stFeats, int nLen, int nID)
{
	char modelName[256];
	int i;
	strcpy(modelName, "SVC");
	//strcpy(modelName, "MatchModel");

	if((model=svm_load_model(modelName))==0)
		return -1;
	x = (struct svm_node *) malloc((nLen +1)*sizeof(struct svm_node));
	memset(x, 0, (nLen +1) * sizeof(struct svm_node));
	
	x[nLen].index = -1;
	int predVal = -1;
	for (i = 0; i < nLen; i++)
	{		
		x[i].index = i + 1;
		x[i].value = stFeats[i];
	}
	setModeFlag(nID);
	predVal = (int)svm_predict(model, x);
	
	svm_free_and_destroy_model(&model);
	free(x);

	return predVal;
}

int callProbEstimate(float* stFeats, int nLen, int nID, struct svm_prob_estimate* probs)
{
	char modelName[256];
	int i;
	strcpy(modelName, "C:\\SVR");
	//strcpy(modelName, "MatchModel");

	if ((model = svm_load_model(modelName)) == 0)
		return -1;
	x = (struct svm_node *) malloc((nLen + 1)*sizeof(struct svm_node));
	memset(x, 0, (nLen + 1) * sizeof(struct svm_node));

	x[nLen].index = -1;
	int predVal = -1;
	for (i = 0; i < nLen; i++)
	{
		x[i].index = i + 1;
		x[i].value = stFeats[i];
	}
	setModeFlag(nID);
	predVal = (int)(100*svm_predict_probability(model, x, probs->probs));

	svm_free_and_destroy_model(&model);
	free(x);

	return predVal;
}