#ifndef _DEFINE_H_
#define _DEFINE_H_

#define admax(a,b) (((a) > (b)) ? (a) : (b))
#define admin(a,b) (((a) < (b)) ? (a) : (b))


#define VERY_BIG  	(1e30)
#define FS			16000
#define	FEAT_NUM	39
#define FRAME_SHIFT	160
#define FRAME_SIZE	320
#define FRATE 		(FS / FRAME_SHIFT)

#define mfcUnit 		(FRAME_SHIFT)
#define frame2mfc(x) 	(1 + (x-FRAME_SIZE) / FRAME_SHIFT + 1)
#define mfc2frame(x) 	(x * mfcUnit) //((x-2)*FRAME_SHIFT+FRAME_SIZE)
#define mfc2time(x)  	((float)x/FRATE)
#define time2frame(x)	((int)(FS*x))

#define MAX_INT16 0x3FFF

#define _BENCH	0
#define _SAMPLE	1

#define CMD_MATCHING	0
#define CMD_TRAIN		1
#define CMD_TEST		2
#define CMD_ERROR		3

#endif
