#ifndef _UTIL_H_
#define _UTIL_H_


float 	getEucDist(float *x1, float *x2);
void	getDistanceMatirx(float** distMat, float **Mat0, float **Mat1, int row0, int row1);
float	getKurt(int* varData, int nLen);

void	saveMat2File(float** matData, int nRow, int nCol, char* fname);
#endif // ifndef _UTIL_H_
