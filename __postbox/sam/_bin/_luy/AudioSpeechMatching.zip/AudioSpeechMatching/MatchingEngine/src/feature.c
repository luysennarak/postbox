
#include "feature.h"
#include "svm.h"
#include "define.h"
#include "util.h"

int bLOG = 1;

int get_mfcc_feat(mfcc_t **mfccMat, short *wavBuffer, int nFrame)
{
	char frates[10];
	fe_t *fe;
	feat_t *fcb;
	mfcc_t **cepbuf, **cptr;

	cmd_ln_t *config;
	size_t nsamp;
	int32 total_frames, nfr;

	sprintf(frates, "%d", FRATE);

	config = cmd_ln_init(NULL, ps_args(), FALSE,
		//"-hmm", MODELDIR,
		"-bestpath", "no",
		"-samprate", "16000",
		"-maxhmmpf", "-1",
		"-frate", frates,
		"-cmn", "batch",
		"-ncep", "39",
		"-remove_silence", "no",
		NULL);


	fe = fe_init_auto_r(config);
	int fe_size = fe_get_output_size(fe);
	fcb = feat_init("1s_c_d_dd", CMN_BATCH, TRUE, AGC_NONE, TRUE, fe_size);

	nsamp = nFrame;
	fe_process_frames(fe, NULL, &nsamp, NULL, &total_frames, NULL);

	total_frames++; /* For the possible fe_end_utt() frame */
	cepbuf = (mfcc_t**)ckd_calloc_2d(total_frames + 1, fe_size, sizeof(**cepbuf));

	fe_start_utt(fe);
	cptr = cepbuf;
	nfr = total_frames;

	int16 *bptr;
	bptr = wavBuffer;
	while (nsamp) {
		int32 ncep = nfr;
		fe_process_frames(fe, &bptr, &nsamp, cptr, &ncep, NULL);
		cptr += ncep;
		nfr -= ncep;
	}
	fe_end_utt(fe, *cptr, &nfr);

	int row, col;
	for (row = 0; row < total_frames; row++) {
		for (col = 0; col < fe_size; col++) {
			mfccMat[row][col] = cepbuf[row][col];
		}
	}

// 	FILE* fp = fopen("matMFCC.csv", "w");
// 	if (fp) {
// 		for (row = 0; row < total_frames; row++) {
// 			for (col = 0; col < fe_size; col++) {
// 				if (col < fe_size - 1)
// 					fprintf(fp, "%.3f,", mfccMat[row][col]);
// 				else
// 					fprintf(fp, "%.3f\n", mfccMat[row][col]);
// 			}
// 		}
// 		fclose(fp);
// 	}

	ckd_free_2d(cepbuf);
	return total_frames;
}

void getpitch(int *pit, short *wavBuffer, int nSamples)
{
	int frame_shift, frame_size;
	frame_size = FRAME_SIZE;
	frame_shift = FRAME_SHIFT;
	int nfr;
	int16 *buf;
	size_t nsamp, start;
	yin_t *pe;
	uint16 period, bestdiff;

	nsamp = nSamples;
	buf = wavBuffer;
	
	pe = yin_init(frame_size, 0.1, 0.2, 2);
	yin_start(pe);

	nfr = 0;
	for (start = 0; start + frame_size < nsamp; start += frame_shift) {
		yin_write(pe, buf + start);
		if (yin_read(pe, &period, &bestdiff)) {
			if (bestdiff < 0.2 * 32768)
				pit[nfr] = period ? FS / period : 0;
			else
				pit[nfr] = 0;
			if (pit[nfr] == FS) pit[nfr] = 0;
			++nfr;
		}
	}
	yin_end(pe);

	while (yin_read(pe, &period, &bestdiff)) {
		if (bestdiff < 0.2 * 32768)
			pit[nfr] = period ? FS / period : 0;
		else
			pit[nfr] = 0;
		if (pit[nfr] == FS) pit[nfr] = 0;
		++nfr;
	}
	yin_free(pe);
}

float	removeNoise(short* sig, int nSamples, int* nStart, int* nEnd)
{
#if 0 // BY_PITCH
	int nFrame = frame2mfc(nSamples);
	int* bufPitch = (int*)malloc(sizeof(int)*nFrame);

	// get pitch feature
	getpitch(bufPitch, sig, nSamples);
	
	int i;
	// search first position of voice
	for (i = 0; i < nFrame; i++) {
		if (bufPitch[i] > 0)
			break;
	}
	*nStart = min(i, nFrame-1);

	// search last position
	for (i = nFrame - 1; i >= 0; i--) {
		if (bufPitch[i] > 0)
			break;
	}
	*nEnd = max(i, 0);

	free(bufPitch);
#else // BY_ENERGY
	int nFrame = frame2mfc(nSamples);
	float* bufEnergy = (float*)ckd_calloc(nFrame, sizeof(float));

	// get energy
	getEnergy(bufEnergy, sig, nSamples);

	int i, k;
	
	// get max energy value
	float energyMaxValue = 0.0;
	for (i = 0; i < nFrame; i++)
		if (bufEnergy[i] > energyMaxValue)
			energyMaxValue = bufEnergy[i];
	
	float* copyEnergy = (float*)ckd_calloc(nFrame, sizeof(float));
	memcpy(copyEnergy, bufEnergy, nFrame*sizeof(float));


	// moving averaging filter with a 9-frames sliding window
	float sum = 0.0;
	for(i=4; i<nFrame-4; i++){
		sum = 0.0;
		for(k=i-4; k<=i+4; k++){
			sum += bufEnergy[k];
		}
		sum /= 9.0;
		copyEnergy[i] = sum;
	}

	// sorting energy array
	for(i=0; i<nFrame; i++){
		float tmp;
		for(k=i+1; k<nFrame; k++){
			if(copyEnergy[i] > copyEnergy[k]){
				tmp = copyEnergy[i];
				copyEnergy[i] = copyEnergy[k];
				copyEnergy[k] = tmp;
			}
		}
	}

	// calculation of threshold thita1, thita2
	// thita1, thita2 represent values of sorted copyEnergy that correspond
	// to the 20% and 80% length(or indices) of the copyEnergy vector
	float thita1 = copyEnergy[(int)(nFrame*0.1)];
	float thita2 = copyEnergy[(int)(nFrame*0.9)];

	float thita = (thita1 + thita2) / 2.0;

	// search first position of voice
	for (i = 0; i < nFrame; i++) {
		if (bufEnergy[i] > thita)
			break;
	}
	*nStart = min(i, nFrame - 1);

	// search last position
	for (i = nFrame - 1; i >= 0; i--) {
		if (bufEnergy[i] > thita)
			break;
	}
	*nEnd = max(i, 0);

	ckd_free(copyEnergy);
	ckd_free(bufEnergy);
#endif
	return energyMaxValue;
}

float stZCR(short* frame, int nLen)
{
	int i, countZ = 0;
	for(i=0; i<nLen-1; i++){
		if(frame[i]*frame[i+1] < 0)
			countZ++;
	}

	return (float)countZ / (float)(nLen-1);
}

void getEnergy(float* energy, short* sig, int nSamples)
{
	int i, j, k;
	long double sum;
	for (i = 0, k = 0; i + FRAME_SIZE <= nSamples; i += FRAME_SHIFT) {
		sum = 0;
		for (j = i; j < i + FRAME_SIZE; j++)
			sum += (sig[j] * sig[j]);
		sum = (float)(sum/FRAME_SIZE);
		if (sum == 0)
			energy[k++] = 0.0;
		else
			energy[k++] = (float)log10(sum)*10.0;
	}
}

int getSvmPredict(mfcc_t** mfccMat0, int nLen0, mfcc_t** mfccMat1, int nLen1, int* pitch0, int* pitch1, int nID)
{
	int i;

	// get SVM predict data
	svm_feat *stFeat = NULL;
	stFeat = (svm_feat *)malloc(sizeof(*stFeat));
	getSVMFeatures_New(mfccMat0, nLen0, mfccMat1, nLen1, pitch0, pitch1, stFeat);

	// svm-scale
	FILE* fp;
	fp = fopen("C:\\SCALE", "r");
	if (fp) {
		int a, b, id;
		char axis;
		float m[6], M[6];

		fscanf(fp, "%c", &axis);
		fscanf(fp, "%d %d", &a, &b);
		fscanf(fp, "%d %f %f", &id, &m[0], &M[0]);
		fscanf(fp, "%d %f %f", &id, &m[1], &M[1]);
		fscanf(fp, "%d %f %f", &id, &m[2], &M[2]);
		fscanf(fp, "%d %f %f", &id, &m[3], &M[3]);
		fscanf(fp, "%d %f %f", &id, &m[4], &M[4]);
		fscanf(fp, "%d %f %f", &id, &m[5], &M[5]);
		fclose(fp);

		stFeat->yFeats[0] = (float)(a + (float)(b - a)*(stFeat->yFeats[0] - m[0]) / (M[0] - m[0]));
		stFeat->yFeats[1] = (float)(a + (float)(b - a)*(stFeat->yFeats[1] - m[1]) / (M[1] - m[1]));
		stFeat->yFeats[2] = (float)(a + (float)(b - a)*(stFeat->yFeats[2] - m[2]) / (M[2] - m[2]));
		stFeat->yFeats[3] = (float)(a + (float)(b - a)*(stFeat->yFeats[3] - m[3]) / (M[3] - m[3]));
		stFeat->yFeats[4] = (float)(a + (float)(b - a)*(stFeat->yFeats[4] - m[4]) / (M[4] - m[4]));
		stFeat->yFeats[5] = (float)(a + (float)(b - a)*(stFeat->yFeats[5] - m[5]) / (M[5] - m[5]));
	}

	if (bLOG) {
		printf("\n");
		printf("\tFeature extraction:\n");
		printf("\t\t dist_incline / dist_path  : %f\n", stFeat->yFeats[0]);
		printf("\t\t average of distance block : %f\n", stFeat->yFeats[1]);
		printf("\t\t average diff-value of SSMs: %f\n", stFeat->yFeats[2]);
		printf("\t\t Length_path/Length_incline: %f\n", stFeat->yFeats[3]);
		printf("\t\t Kurtosis: %f\n", stFeat->yFeats[4]);
		printf("\t\t shape-difference value    : %f\n", stFeat->yFeats[5]);
	}


	// call SVM predict
	float* svmFeat = (float*)malloc(10*sizeof(float));
	for (i = 0; i < 6; i++)
		svmFeat[i] = stFeat->yFeats[i];

	int nResult;

	struct svm_prob_estimate fe;
	fe.nClass = 6;
	fe.probs = (double*)malloc(fe.nClass*sizeof(double));
	nResult = callProbEstimate(svmFeat, 6, nID, &fe);
	nResult = admin(100, admax(0, nResult));

	
	printf("\n");

	if (bLOG)
		printf("\tscore: %d%%\n", nResult);

	free(fe.probs);
	free(svmFeat);
	free(stFeat);	
	
	return nResult;
}

int getSVMFeatures(mfcc_t** mfc0, int row0, mfcc_t** mfc1, int row1, mfcc_t** mfc1_inv, int* pitch0, int* pitch1, svm_feat* stFeat)
{
	// 1. average difference according to incline of the distance matrix
	// 2. average difference according to path of the distance matrix
	// 3. average difference according to inverse path of the distance matrix
	// 4. kurtosis
	// 5. pitch feature
	int i, j, k;

	float** dist_T_SSM = (float**)ckd_calloc_2d(row0, row0, sizeof(float));
	float** dist_S_SSM = (float**)ckd_calloc_2d(row1, row1, sizeof(float));
	getDistanceMatirx(dist_T_SSM, mfc0, mfc0, row0, row0);
	getDistanceMatirx(dist_S_SSM, mfc1, mfc1, row1, row1);

	float dist_IncLine, dist_path, dist_inv_path;

	for (i = 0; i < 1; i++) {
		int st0, et0, st1, et1;
		st0 = 0;
		et0 = row0 - 1;
		st1 = 0;
		et1 = row1 - 1;

		if (st0 == et0 || st1 == et1) {
			for (j = 0; j < 5; j++)
				stFeat->yFeats[j] = (float)VERY_BIG;
			continue;
		}

		int ii, jj, n = 0;
		// average distance along the diagonal of the block of the word
		dist_IncLine = 0;
		for (j = st1; j <= et1; j++) {
			ii = st0 + (int)(j - st1)*(et0 - st0) / (et1 - st1);
			dist_IncLine += getEucDist(mfc0[ii], mfc1[j]);
			n++;
		}
		dist_IncLine = dist_IncLine / (float)n;

		// average distance along aligned path
		int subRow0 = et0 - st0 + 1;
		int subRow1 = et1 - st1 + 1;
		float** subMfc0 = (float**)ckd_calloc_2d(subRow0, FEAT_NUM, sizeof(float));
		float** subMfc1 = (float**)ckd_calloc_2d(subRow1, FEAT_NUM, sizeof(float));
		for (j = st0; j <= et0; j++)
			for (k = 0; k < FEAT_NUM; k++)
				subMfc0[j - st0][k] = mfc0[j][k];
		for (j = st1; j <= et1; j++)
			for (k = 0; k < FEAT_NUM; k++)
				subMfc1[j - st1][k] = mfc1[j][k];

		int** subPath = (int**)ckd_calloc_2d(2, 2 * (subRow0 + subRow1), sizeof(int));
		int subPathLen = 0;
		float** subDistMat;
		subDistMat = (float**)ckd_calloc_2d(subRow0, subRow1, sizeof(float));
		getDistanceMatirx(subDistMat, subMfc0, subMfc1, subRow0, subRow1);
#ifdef _DEBUG
		saveMat2File(subDistMat, subRow0, subRow1, "distMat0.csv");
#endif
		get_DTW_Path(subDistMat, subRow0, subRow1, subPath, &subPathLen, 0);

		dist_path = 0;
		for (j = 0; j < subPathLen; j++) {
			ii = subPath[0][j];
			jj = subPath[1][j];
			dist_path += subDistMat[ii][jj];
		}
		dist_path = dist_path / (float)subPathLen;

		// absolute element-wise difference between the SSMs of the teacher and the student, averaged by the total area
		float T_avr = 0, S_avr = 0;
		for (ii = st0; ii <= et0; ii++)
			for (jj = st0; jj <= et0; jj++)
				T_avr += dist_T_SSM[ii][jj];
		T_avr /= (float)(subRow0*subRow0);

		for (ii = st1; ii <= et1; ii++)
			for (jj = st1; jj <= et1; jj++)
				S_avr += dist_S_SSM[ii][jj];
		S_avr /= (float)(subRow1*subRow1);

		// Kurtosis
		int* arrCounter = (int*)malloc(subRow0*sizeof(int));
		memset(arrCounter, 0, subRow0*sizeof(int));
		for (j = 0; j < subPathLen; j++) {
			arrCounter[subPath[0][j]]++;
		}
		float nLocalKurt = 0;
		nLocalKurt = getKurt(arrCounter, subRow0);
		free(arrCounter);

		// average distance along path by inverse-buffer
// 		float** inverse_mfcc1 = (float**)ckd_calloc_2d(subRow1, FEAT_NUM, sizeof(float));
// 		for (j = 0; j < subRow1; j++)
// 			for (k = 0; k < FEAT_NUM; k++)
// 				inverse_mfcc1[j][k] = subMfc1[subRow1 - 1 - j][k];
		subPathLen = 0;
		getDistanceMatirx(subDistMat, subMfc0, mfc1_inv, subRow0, subRow1);
#ifdef _DEBUG
		saveMat2File(subDistMat, subRow0, subRow1, "distMat1.csv");
#endif
		get_DTW_Path(subDistMat, subRow0, subRow1, subPath, &subPathLen, 1);

		dist_inv_path = 0;
		for (j = 0; j < subPathLen; j++) {
			ii = subPath[0][j];
			jj = subPath[1][j];
			dist_inv_path += subDistMat[ii][jj];
		}
		dist_inv_path = dist_inv_path / (float)subPathLen;
//		ckd_free_2d(inverse_mfcc1);

		// local pitch feature(accent, tone)
//		int pitFeat = getLocalPitchFeatures(pitch0, pitch1, row0, row1);

		stFeat->yFeats[0] = dist_path; //dist_path - dist_IncLine;
		stFeat->yFeats[1] = dist_IncLine; //dist_inv_path - dist_path;
		stFeat->yFeats[2] = dist_inv_path; //S_avr - T_avr;
		stFeat->yFeats[3] = nLocalKurt;
		stFeat->yFeats[4] = S_avr - T_avr;

		ckd_free_2d(subMfc0);
		ckd_free_2d(subMfc1);
		ckd_free_2d(subPath);
		ckd_free_2d(subDistMat);
	}
	ckd_free_2d(dist_T_SSM);
	ckd_free_2d(dist_S_SSM);
	return 0;
}

int getSVMFeatures_New(mfcc_t** mfc0, int row0, mfcc_t** mfc1, int row1, int* pitch0, int* pitch1, svm_feat* stFeat)
{
	// 1. average distance along the aligned path, along the diagonal of the distance matrix, and the difference / ratio between the two
	// 2. average distance within the distance matrix
	// 3. the difference between the average distance of the distance matrix and the SSM of standard
	// 4. 
	// 5. Ratio between length of diagonal and length of aligned path
	// 6. kurtosis of histogram of aligned path curve
	// 7. shape-difference between aligned path and diagonal

	int i, j, k;
	memset(stFeat->yFeats, 0, sizeof(float) * 10);

	float** dist_T_SSM = (float**)ckd_calloc_2d(row0, row0, sizeof(float));
	float** dist_S_SSM = (float**)ckd_calloc_2d(row1, row1, sizeof(float));
	getDistanceMatirx(dist_T_SSM, mfc0, mfc0, row0, row0);
	getDistanceMatirx(dist_S_SSM, mfc1, mfc1, row1, row1);
	
	saveMat2File(dist_T_SSM, row0, row0, "ssm0.csv");
	saveMat2File(dist_S_SSM, row1, row1, "ssm1.csv");


	float dist_IncLine, dist_path;
	int lenPath = 0, lenIncLine = 0;

	for (i = 0; i < 1; i++) {
		int st0, et0, st1, et1;
		st0 = 0;
		et0 = row0 - 1;
		st1 = 0;
		et1 = row1 - 1;

		if (st0 == et0 || st1 == et1) {
			for (j = 0; j < 10; j++)
				stFeat->yFeats[j] = (float)VERY_BIG;
			continue;
		}

		int ii, jj;
		// feature1
		// average distance along the diagonal of the block of the word
		dist_IncLine = 0;
		for (j = st1; j <= et1; j++) {
			ii = st0 + (int)(j - st1)*(et0 - st0) / (et1 - st1);
			dist_IncLine += getEucDist(mfc0[ii], mfc1[j]);
			lenIncLine++;
		}
		dist_IncLine = dist_IncLine / (float)lenIncLine;

		// average distance along the aligned path
		int** subPath = (int**)ckd_calloc_2d(2, 2 * (row0 + row1), sizeof(int));
		int subPathLen = 0;
		float** distMat;
		distMat = (float**)ckd_calloc_2d(row0, row1, sizeof(float));
		getDistanceMatirx(distMat, mfc0, mfc1, row0, row1);

		saveMat2File(distMat, row0, row1, "distMat0.csv");

		get_DTW_Path(distMat, row0, row1, subPath, &subPathLen, 0);

		dist_path = 0;
		for (j = 0; j < subPathLen; j++) {
			ii = subPath[0][j];
			jj = subPath[1][j];
			dist_path += distMat[ii][jj];
		}
		dist_path = dist_path / (float)subPathLen;
		lenPath = subPathLen;

		float f1 = (dist_path == 0) ? 1.0 : dist_IncLine / dist_path;

		// feature2
		float f2 = 0.0;
		for (i = 0; i < row0; i++)
			for (j = 0; j < row1; j++)
				f2 += distMat[i][j];
		f2 /= (float)(row0*row1);

		// feature3
		float f3 = 0.0;
		for (i = 0; i < row0; i++)
			for (j = 0; j < row0; j++)
				f3 += dist_T_SSM[i][j];
		f3 /= (float)(row0*row0);
		f3 = f2 - f3;

		// feature4

		// feature5
		float f5 = (float)lenIncLine / (float)lenPath;

		// feature6 (Kurtosis)
		int* arrCounter = (int*)malloc(row0*sizeof(int));
		memset(arrCounter, 0, row0*sizeof(int));
		for (j = 0; j < subPathLen; j++) {
			arrCounter[subPath[0][j]]++;
		}
		float f6 = getKurt(arrCounter, row0) / (float)lenIncLine;
		free(arrCounter);

		// feature7
		int ii0, jj0;
		float f7 = 0.0;
		for (k = 0; k < subPathLen; k++) {
			ii = subPath[0][k];
			jj = subPath[1][k];
			ii0 = st0 + (int)(jj - st1)*(et0 - st0) / (et1 - st1);
			jj0 = jj;
			f7 += sqrtf((ii - ii0)*(ii - ii0) + (jj - jj0)*(jj - jj0));
		}
		f7 /= (float)subPathLen;

		stFeat->yFeats[0] = f1;
		stFeat->yFeats[1] = f2;
		stFeat->yFeats[2] = f3;
		stFeat->yFeats[3] = f5;
		stFeat->yFeats[4] = f6;
		stFeat->yFeats[5] = f7;

		ckd_free_2d(subPath);
		ckd_free_2d(distMat);
	}

	ckd_free_2d(dist_T_SSM);
	ckd_free_2d(dist_S_SSM);
	return 0;
}

void get_DTW_Path(float **distMat, int row0, int row1, int **path, int* len, int nMode)
{
	float **globdist;

	float top, mid, bot, cheapest;
	int **move;
	int **warp;

	int I, X, Y, n, i, j;

	/* allocate memory for globdist */
	globdist = ckd_calloc_2d(row0, row1, sizeof(float));

	/* allocate memory for move */
	move = ckd_calloc_2d(row0, row1, sizeof(int));

	/* allocate memory for warp */
	warp = ckd_calloc_2d((row0 + row1) * 2, 2, sizeof(int));

	// Warping in progress ...
	globdist[0][0] = distMat[0][0];
	for (j = 1; j < row0; j++)
		globdist[j][0] = (float)VERY_BIG;
	for (i = 1; i < row1; i++)
		globdist[0][i] = (float)VERY_BIG;
	globdist[1][1] = globdist[0][0] + distMat[1][1];
	move[1][1] = 2;

	for (i = 1; i < row1; i++) {

		for (j = 1; j < row0; j++) {
			top = globdist[j][i - 1] + distMat[j][i];
			mid = globdist[j - 1][i - 1] + distMat[j][i];
			bot = globdist[j - 1][i] + distMat[j][i];
			if ((top < mid) && (top < bot))
			{
				cheapest = top;
				I = 1;
			}
			else if (mid < bot)
			{
				cheapest = mid;
				I = 2;
			}
			else {
				cheapest = bot;
				I = 3;
			}

			/*if all costs are equal, pick middle path*/
			if ((top == mid) && (mid == bot))
				I = 2;

			globdist[j][i] = cheapest;
			move[j][i] = I;
		}
	}

	X = row1 - 1; Y = row0 - 1; n = 0;
	warp[n][0] = Y; warp[n][1] = X;

	while (X > 0 && Y > 0) {
		n = n + 1;

		if (n > (row0 + row1) * 2) {
			fprintf(stderr, "Warning: warp matrix too large!");
			*len = 0;
			return;
		}

		if (move[Y][X] == 1)
		{
			X = X - 1;
		}
		else if (move[Y][X] == 2)
		{
			X = X - 1; Y = Y - 1;
		}
		else if (move[Y][X] == 3)
		{
			Y = Y - 1;
		}

		warp[n][0] = Y;
		warp[n][1] = X;
	}


// 	FILE*fp;
// 	if (nMode == 0)
// 		fp = fopen("path0.csv", "w");
// 	else
// 		fp = fopen("path1.csv", "w");

	for (i = 0; i <= n; i++) {
		path[0][i] = warp[n - i][0];
		path[1][i] = warp[n - i][1];
// 		if(fp)
// 			fprintf(fp, "%d,%d\n", path[0][i]+1, path[1][i]+1);

	}
// 	if(fp)
// 		fclose(fp);

	*len = n + 1;

	ckd_free_2d(globdist);
	ckd_free_2d(move);
	ckd_free_2d(warp);
}


int getLocalPitchFeatures(int *P0, int *P1, int row0, int row1)
{
	int i, j;
	salience sTones[2];

	float aver = 0;
	int n = 0, localMax = 0;
	int st = 0;
	int et = row0-1;
	int nInitial = 0, nFinal = 0, localPos = 0;
	int duration = et - st + 1;
	for (j = st; j <= et; j++) {
		aver += (float)P0[j];
		if (P0[j] > localMax) {
			if (j > st && j < et) {
				localMax = P0[j];
				localPos = j;
			}
		}
		if (nInitial == 0 && P0[j] > 0)
			nInitial = P0[j];
		if (P0[j] > 0)
			nFinal = P0[j];
		n++;
	}
	aver = aver / (float)n;

	sTones[0].nInitial = (float)12.0 * log2((float)nInitial / aver);
	sTones[0].nFinal = (float)12.0 * log2((float)nFinal / aver);
	sTones[0].nMainPos = (float)(localPos - st) / duration;
	sTones[0].nMain = (float)12.0 * log2((float)localMax / aver);
	sTones[0].nMean = aver;
	getPitchLevel(&sTones[0]);

	aver = 0;
	n = 0, localMax = 0;
	st = 0;
	et = row1-1;
	nInitial = 0, nFinal = 0, localPos = 0;
	duration = et - st + 1;
	for (j = st; j <= et; j++) {
		aver += (float)P1[j];
		if (P1[j] > localMax) {
			if (j > st && j < et) {
				localMax = P1[j];
				localPos = j;
			}
		}
		if (nInitial == 0 && P1[j] > 0)
			nInitial = P1[j];
		if (P1[j] > 0)
			nFinal = P1[j];
		n++;
	}
	aver = aver / (float)n;

	sTones[1].nInitial = (float)12.0 * log2((float)nInitial / aver);
	sTones[1].nFinal = (float)12.0 * log2((float)nFinal / aver);
	sTones[1].nMainPos = (float)(localPos - st) / duration;
	sTones[1].nMain = (float)12.0 * log2((float)localMax / aver);
	sTones[1].nMean = aver;
	getPitchLevel(&sTones[1]);

	// evaluation
	int feats0 = sTones[0].pitchLevel;
	int feats1 = sTones[1].pitchLevel;
	int tone0 = getToneRythm(feats0 / 10);
	int tone1 = getToneRythm(feats1 / 10);

	int accent[2];
	accent[0] = feats0 % 10;
	accent[1] = feats1 % 10;
	

	int diff = 0;
	diff += (accent[0] - accent[1])*(accent[0] - accent[1]);
	diff += (tone0 / 10 - tone1 / 10)*(tone0 / 10 - tone1 / 10);
	diff += (tone0 % 10 - tone1 % 10)*(tone0 % 10 - tone1 % 10);

	return diff;
}

void getPitchLevel(salience *ST)
{
	int nLevel = 0;
	// initial
	if (ST->nInitial < -6.0)
		nLevel += 1;
	else if (ST->nInitial < -2.0)
		nLevel += 2;
	else if (ST->nInitial < 2.0)
		nLevel += 3;
	else if (ST->nInitial < 6.0)
		nLevel += 4;
	else
		nLevel += 5;
	nLevel *= 10;
	// main saliency
	if (ST->nMain < -6.0)
		nLevel += 1;
	else if (ST->nMain < -2.0)
		nLevel += 2;
	else if (ST->nMain < 2.0)
		nLevel += 3;
	else if (ST->nMain < 6.0)
		nLevel += 4;
	else
		nLevel += 5;
	nLevel *= 10;
	// final
	if (ST->nFinal < -6.0)
		nLevel += 1;
	else if (ST->nFinal < -2.0)
		nLevel += 2;
	else if (ST->nFinal < 2.0)
		nLevel += 3;
	else if (ST->nFinal < 6.0)
		nLevel += 4;
	else
		nLevel += 5;

	nLevel *= 10;
	// time position of main saliency (accent)
	if (ST->nMainPos < (float)1 / 3)
		nLevel += 1;
	else if (ST->nMainPos < (float)2 / 3)
		nLevel += 2;
	else
		nLevel += 3;

	ST->pitchLevel = nLevel;
}

int	getToneRythm(int pitchTone)
{
	if (pitchTone < 100 || pitchTone>999)
		return 0;
	int tone = 0;
	int piTone[3];
	piTone[0] = pitchTone % 10;
	piTone[1] = (pitchTone / 10) % 10;
	piTone[2] = pitchTone / 100;
	// equal tone : 1
	// inc   tone : 2
	// dec   tone : 3
	if (fabs(piTone[2] - piTone[1]) < 2.0)
		tone = 1;
	else if (piTone[2] >= piTone[1] + 2)
		tone = 3;
	else
		tone = 2;

	tone *= 10;
	if (fabs(piTone[1] - piTone[0]) <= 2.0)
		tone += 1;
	else if (piTone[1] > piTone[0] + 2)
		tone += 3;
	else
		tone += 2;

	return tone;
}