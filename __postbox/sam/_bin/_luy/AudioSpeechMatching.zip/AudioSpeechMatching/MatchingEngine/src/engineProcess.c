
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "engineInterface.h"

#ifdef _WIN32
#include <Windows.h>
#include <direct.h>
#else
#define <dirent.h>
#endif

#include "define.h"
#include "feature.h"
#include "util.h"
#include "sndfile.h"
#include "myVector.h"

extern int bLOG;
mvector vecFiles;

int findFilesInDir(char* srtPath)
{
#ifdef _WIN32
	WIN32_FIND_DATA fdFile;
	HANDLE hFind = NULL;

	char sPath[256];
	//Specify a file mask. *.* = We want everything!
	sprintf(sPath, "%s\\*.*", srtPath);

	if ((hFind = FindFirstFile(sPath, &fdFile)) == INVALID_HANDLE_VALUE)
	{
		printf("Path not found: [%s]\n", srtPath);
		return -1;
	}
	do
	{
		//Find first file will always return "."
		//    and ".." as the first two directories.
		if (strcmp(fdFile.cFileName, ".") != 0
			&& strcmp(fdFile.cFileName, "..") != 0)
		{
			sprintf(sPath, "%s\\%s", srtPath, fdFile.cFileName);
			//Is the entity a File or Folder?
			if (fdFile.dwFileAttributes &FILE_ATTRIBUTE_DIRECTORY)
			{
				//printf("Directory: %s\n", sPath);
				findFilesInDir(sPath); //Recursion, I love it!
			}
			else {
				//printf("File: %s\n", sPath);
				
				if (strcmp(sPath + strlen(sPath) - 4, ".wav") == 0 || strcmp(sPath + strlen(sPath) - 4, ".WAV") == 0)
				{
					char* tmpPath = (char*)malloc(256);
					strcpy(tmpPath, sPath);
					vector_add(&vecFiles, tmpPath);
				}
			}
		}
	} while (FindNextFile(hFind, &fdFile)); //Find the next file.

	FindClose(hFind); //Always, Always, clean things up!
#else
	DIR* dirp = opendir(srtPath);
	struct dirent* dp;
	if (dirp == NULL)
		return -1;
	while ((dp = readdir(dirp)) != NULL) {
		// if dp is not a file
		if (dp->d_type == DT_DIR) {
			if (strncmp(dp->d_name, "..", 2) == 0 || strncmp(dp->d_name, ".", 1) == 0)
				continue;
			// search files in directory recursively
			char path[256];
			sprintf(path, "%s/%s", srtPath, dp->d_name);
			findFilesInDir(path);
		}
		// if dp is wave audio file
		if (strcmp(dp->d_name + strlen(dp->d_name) - 4, ".wav") == 0 ||
			strcmp(dp->d_name + strlen(dp->d_name) - 4, ".WAV") == 0) {
			// add wave file name to vector list
			char* wavFileName = (char*)malloc(256);
			strcpy(wavFileName, srtPath);
			strcat(wavFileName, "/");
			strcat(wavFileName, dp->d_name);
			vector_add(&vecFiles, wavFileName);
		}
	}
	closedir(dirp);
#endif
	return 0;
}

/*
 * search wave files in directory <dirName> and
 * train svm-features from those files.
 */
int makeTrainData(char* dirName)
{
	vector_init(&vecFiles);

	if (findFilesInDir(dirName) < 0)
		return -1;
	int i, N = vector_total(&vecFiles);
	char *audioName1 = (char*)malloc(256);
	char *audioName2 = (char*)malloc(256);
	char *tmpName = (char*)malloc(64);

	for (i = 0; i < N; i++) {
		strcpy(audioName2, (char *)vector_get(&vecFiles, i));		

		if (strlen(audioName2) > 15 && strstr(audioName2, "standard"))
			continue;

		// named that: _70-01.wav (nProb=70, nIndex=1)
		int len = strlen(audioName2);
		if (len < 10) continue;

		// get nIndex value
		strncpy(tmpName, audioName2 + len - 6, 2);
		tmpName[2] = '\0';
		if (!isdigit(tmpName[0]) || audioName2[len-7] != '-')
			continue;
		int nIndex = atoi(tmpName);

		// get probability value. for example, 70
		int pos = len-1 - 7;
		for (; pos >= 0; pos--)
			if (!isdigit(audioName2[pos]))
				break;
		pos++;
		if (pos > len - 1 || len - 7 - pos < 1)
			continue;
		strncpy(tmpName, audioName2 + pos, len - 7 - pos);
		tmpName[len - 7 - pos] = '\0';

		if (!isdigit(tmpName[0]))
			continue;
		int nProb = atoi(tmpName);

		// get standard file name
		strncpy(audioName1, audioName2, pos);
		audioName1[pos] = '\0';
		sprintf(tmpName, "standard-%02d.wav", nIndex);
		strcat(audioName1, tmpName);

		// write feature data
		writeSVMdata(audioName1, audioName2, nProb);
	}

	vector_free(&vecFiles);
	free(audioName1); free(audioName2);
	free(tmpName);

	return 0;
}


int writeSVMdata(char* fname1, char* fname2, int nID)
{
	int nSample1 = getFrameCount(fname1);
	int nSample2 = getFrameCount(fname2);

	if (nSample1 <= 0 || nSample2 <= 0) {
		return -1;
	}

	int i, j, k;

	fprintf(stdout, "matching with %d%%\n\t%s\n\t%s\n", nID, fname1, fname2);

	short *audioBuf1 = (short*)malloc(nSample1 * sizeof(short));
	short *audioBuf2 = (short*)malloc(nSample2 * sizeof(short));

	nSample1 = readWavFile(fname1, audioBuf1);
	nSample2 = readWavFile(fname2, audioBuf2);

	int N1 = (int)frame2mfc(nSample1) + 10;
	int N2 = (int)frame2mfc(nSample2) + 10;

	mfcc_t **mfccMat1 = (mfcc_t**)ckd_calloc_2d(N1, FEAT_NUM, sizeof(mfcc_t));
	mfcc_t **mfccMat2 = (mfcc_t**)ckd_calloc_2d(N2, FEAT_NUM, sizeof(mfcc_t));

	int nMfccDim1 = get_mfcc_feat(mfccMat1, audioBuf1, nSample1);
	int nMfccDim2 = get_mfcc_feat(mfccMat2, audioBuf2, nSample2);

	// pitch
	int* pitch1 = (int*)ckd_calloc(nMfccDim1, sizeof(int));
	int* pitch2 = (int*)ckd_calloc(nMfccDim2, sizeof(int));
	getpitch(pitch1, audioBuf1, nSample1);
	getpitch(pitch2, audioBuf2, nSample2);

	// VAD processing
	int nStFrame1 = 0, nEdFrame1 = nMfccDim1 - 1;
	int nStFrame2 = 0, nEdFrame2 = nMfccDim2 - 1;

	removeNoise(audioBuf1, nSample1, &nStFrame1, &nEdFrame1);
	removeNoise(audioBuf2, nSample2, &nStFrame2, &nEdFrame2);

	if (nStFrame1 >= nEdFrame1) {
		nStFrame1 = 0, nEdFrame1 = nMfccDim1 - 1;
	}
	if (nStFrame2 >= nEdFrame2) {
		nStFrame2 = 0, nEdFrame2 = nMfccDim2 - 1;
	}
	// remove noise at start and end
	for (i = 0, j = nStFrame1; j < nEdFrame1; i++, j++) {
		pitch1[i] = pitch1[j];
		for (k = 0; k < FEAT_NUM; k++)
			mfccMat1[i][k] = mfccMat1[j][k];
	}
	nMfccDim1 = nEdFrame1 - nStFrame1;

	for (i = 0, j = nStFrame2; j < nEdFrame2; i++, j++) {
		pitch2[i] = pitch2[j];
		for (k = 0; k < FEAT_NUM; k++)
			mfccMat2[i][k] = mfccMat2[j][k];
	}
	nMfccDim2 = nEdFrame2 - nStFrame2;

	svm_feat * fe = (svm_feat*)malloc(sizeof(svm_feat));
	getSVMFeatures_New(mfccMat1, nMfccDim1, mfccMat2, nMfccDim2, pitch1, pitch2, fe);
	
	// write data
	FILE* fp;
	fp = fopen("SVM_data", "a");
	if (fp) {
		fprintf(fp, "%.2f 1:%.3f 2:%.3f 3:%.3f 4:%.3f 5:%.3f 6:%.3f\n", (float)nID/100.0,
			fe->yFeats[0], fe->yFeats[1], fe->yFeats[2], fe->yFeats[3], fe->yFeats[4], fe->yFeats[5]);
// 		fprintf(fp, "%d 1:%.3f 2:%.3f 3:%.3f 4:%.3f 5:%.3f 6:%.3f\n", nID,
// 			fe->yFeats[0], fe->yFeats[1], fe->yFeats[2], fe->yFeats[3], fe->yFeats[4], fe->yFeats[5]);
		fclose(fp);
	}

	free(fe);
	ckd_free_2d(mfccMat1);
	ckd_free_2d(mfccMat2);
	ckd_free(pitch1);
	ckd_free(pitch2);
	free(audioBuf1);
	free(audioBuf2);

	return 0;
}

int testData(char* dirName)
{
	printf("\n");
	vector_init(&vecFiles);

	if (findFilesInDir(dirName) < 0)
		return -1;
	int i, N = vector_total(&vecFiles);
	char *audioName1 = (char*)malloc(256);
	char *audioName2 = (char*)malloc(256);
	char *tmpName = (char*)malloc(64);
	int nRes = 0;
		
	for (i = 0; i < N; i++) {
		strcpy(audioName2, (char*)vector_get(&vecFiles, i));

		if (strlen(audioName2) > 15 && strstr(audioName2, "standard"))
			continue;

		// named that: _70-01.wav
		int len = strlen(audioName2);
		if (len < 10) continue;

		// get nIndex value
		strncpy(tmpName, audioName2 + len - 6, 2);
		tmpName[2] = '\0';
		if (!isdigit(tmpName[0]) || audioName2[len - 7] != '-')
			continue;
		int nIndex = atoi(tmpName);

		// get probability value. for example, 70
		int pos = len - 1 - 7;
		for (; pos >= 0; pos--)
			if (!isdigit(audioName2[pos]))
				break;
		pos++;
		if (pos > len - 1 || len - 7 - pos < 1)
			continue;
		strncpy(tmpName, audioName2 + pos, len - 7 - pos);
		tmpName[len - 7 - pos] = '\0';

		if (!isdigit(tmpName[0]))
			continue;
		int nProb = atoi(tmpName);

		// get standard file name
		strncpy(audioName1, audioName2, pos);
		audioName1[pos] = '\0';
		sprintf(tmpName, "standard-%02d.wav", nIndex);
		strcat(audioName1, tmpName);

		getTestData(audioName1, audioName2, nProb);	
	}

	vector_free(&vecFiles);
	free(audioName1); free(audioName2); free(tmpName);

	return 0;
}

int getTestData(char* fname1, char* fname2, int nID)
{
	
	int nSample1 = getFrameCount(fname1);
	int nSample2 = getFrameCount(fname2);

	if (nSample1 <= 0 || nSample2 <= 0) {
		//printf("error in reading %s and %s\n", fname1, fname2);
		return -1;
	}

	static int nCount = 0;
	nCount += 1;

	printf("\n%d\ttest with %s and \n\t %s\n", nCount, fname1, fname2);
		
	short *audioBuf1 = (short*)malloc(nSample1 * sizeof(short));
	short *audioBuf2 = (short*)malloc(nSample2 * sizeof(short));

	nSample1 = readWavFile(fname1, audioBuf1);
	nSample2 = readWavFile(fname2, audioBuf2);

	int i, j, k;

	int N1 = (int)frame2mfc(nSample1) + 10;
	int N2 = (int)frame2mfc(nSample2) + 10;

	mfcc_t **mfccMat1 = (mfcc_t**)ckd_calloc_2d(N1, FEAT_NUM, sizeof(mfcc_t));
	mfcc_t **mfccMat2 = (mfcc_t**)ckd_calloc_2d(N2, FEAT_NUM, sizeof(mfcc_t));

	int nMfccDim1 = get_mfcc_feat(mfccMat1, audioBuf1, nSample1);
	int nMfccDim2 = get_mfcc_feat(mfccMat2, audioBuf2, nSample2);

	// pitch
	int* pitch1 = (int*)ckd_calloc(nMfccDim1, sizeof(int));
	int* pitch2 = (int*)ckd_calloc(nMfccDim2, sizeof(int));
	getpitch(pitch1, audioBuf1, nSample1);
	getpitch(pitch2, audioBuf2, nSample2);

	// VAD processing
	int nStFrame1 = 0, nEdFrame1 = nMfccDim1 - 1;
	int nStFrame2 = 0, nEdFrame2 = nMfccDim2 - 1;

	float e1 = removeNoise(audioBuf1, nSample1, &nStFrame1, &nEdFrame1);
	float e2 = removeNoise(audioBuf2, nSample2, &nStFrame2, &nEdFrame2);

	if (e2 + 30 < e1) {
		printf("\n");
		printf("\tVAD process(samples):\n");
		printf("\t\t standard: [%d, %d] => [%d, %d]\n", 0, nSample1, mfc2frame(nStFrame1), mfc2frame(nEdFrame2));
		printf("\n\t(%f, %f)\tscore: %d%%\n", e1, e2, 0);

		ckd_free_2d(mfccMat1);
		ckd_free_2d(mfccMat2);
		ckd_free(pitch1);
		ckd_free(pitch2);

		return 0;
	}

	if (nStFrame1 >= nEdFrame1) {
		nStFrame1 = 0, nEdFrame1 = nMfccDim1 - 1;
	}
	if (nStFrame2 >= nEdFrame2) {
		nStFrame2 = 0, nEdFrame2 = nMfccDim2 - 1;
	}

	// remove noise at start and end	
	for (i = 0, j = nStFrame1; j < nEdFrame1; i++, j++) {
		pitch1[i] = pitch1[j];
		for (k = 0; k < FEAT_NUM; k++)
			mfccMat1[i][k] = mfccMat1[j][k];
	}
	nMfccDim1 = nEdFrame1 - nStFrame1;

	for (i = 0, j = nStFrame2; j < nEdFrame2; i++, j++) {
		pitch2[i] = pitch2[j];
		for (k = 0; k < FEAT_NUM; k++)
			mfccMat2[i][k] = mfccMat2[j][k];
	}
	nMfccDim2 = nEdFrame2 - nStFrame2;
	
	// calculate accuracy
	
// 	float score = 0.0;
// 	int pred = getSvmPredict(&score, mfccMat1, nMfccDim1, mfccMat2, nMfccDim2, mfccMat2_inv, pitch1, pitch2, nID);

	// use svm-predict
	svm_feat * fe = (svm_feat*)malloc(sizeof(svm_feat));
	getSVMFeatures_New(mfccMat1, nMfccDim1, mfccMat2, nMfccDim2, pitch1, pitch2, fe);

	
	// write data
	FILE* fp = fopen("test_data", "a");
	if (fp) {
		fprintf(fp, "%.2f 1:%.3f 2:%.3f 3:%.3f 4:%.3f 5:%.3f 6:%.3f\n", (float)nID/100.0,
			fe->yFeats[0], fe->yFeats[1], fe->yFeats[2], fe->yFeats[3], fe->yFeats[4], fe->yFeats[5]);
// 		fprintf(fp, "%d 1:%.3f 2:%.3f 3:%.3f 4:%.3f 5:%.3f 6:%.3f\n", nID,
// 			fe->yFeats[0], fe->yFeats[1], fe->yFeats[2], fe->yFeats[3], fe->yFeats[4], fe->yFeats[5]);
		fclose(fp);
	}
	free(fe);
	
	fp = fopen("test_prob", "a");
	if (fp) {
		fprintf(fp, "%.2f\n", (float)nID / 100.0);
		fclose(fp);
	}
	ckd_free_2d(mfccMat1);
	ckd_free_2d(mfccMat2);
	ckd_free(pitch1);
	ckd_free(pitch2);
	free(audioBuf1);
	free(audioBuf2);
	return 0;
}

int getFrameCount(char *wavname)
{
	SNDFILE	*infile = NULL;
	SF_INFO sfinfo;

	sf_count_t	count;

	if ((infile = sf_open(wavname, SFM_READ, &sfinfo)) == NULL)
		return -1;
	count = sfinfo.frames;
	sf_close(infile);
	return (int)count;
}

int readWavFile(char* inFileName, short* wavBuffer)
{
	SNDFILE	*infile = NULL;
	SF_INFO sfinfo;
	sf_count_t	count, i;

	if ((infile = sf_open(inFileName, SFM_READ, &sfinfo)) == NULL) {
		fprintf(stderr, "%s file cannot open.\n", inFileName);
		return -1;
	}

	if (sf_seek(infile, 0, SEEK_SET) < 0) {
		fprintf(stderr, "Error occurs in reading %s file!\n", inFileName);
		return -1;
	}
	if (sfinfo.samplerate != FS)
	{
		fprintf(stderr, "%s is not 16KHz.\n", inFileName);
		sf_close(infile);
		return -1;
	}
	count = sfinfo.frames;

	unsigned int nChannels = sfinfo.channels;
	float* m_buffer = (float*)malloc((size_t)count*nChannels*sizeof(float));
	short* results = wavBuffer;

	count = sf_readf_float(infile, m_buffer, sfinfo.frames);
	for (i = 0; i < count; ++i) {
		results[i] = (short)(MAX_INT16*m_buffer[i*nChannels]);  // select only first channel
	}

	free(m_buffer);
	sf_close(infile);
	return (int)count;
}


int getMatchingResult(short* benchBuf, int benchLength, short* sampleBuf, int sampleLength)
{
	int i, j, k;

	int N0 = (int)frame2mfc(benchLength) + 10;
	int N1 = (int)frame2mfc(sampleLength) + 10;

	mfcc_t **mfccMat0 = (mfcc_t**)ckd_calloc_2d(N0, FEAT_NUM, sizeof(mfcc_t));
	mfcc_t **mfccMat1 = (mfcc_t**)ckd_calloc_2d(N1, FEAT_NUM, sizeof(mfcc_t));

	int nMfccDim0 = get_mfcc_feat(mfccMat0, benchBuf, benchLength);
	int nMfccDim1 = get_mfcc_feat(mfccMat1, sampleBuf, sampleLength);

	// pitch
	int* pitch0 = (int*)ckd_calloc(nMfccDim0, sizeof(int));
	int* pitch1 = (int*)ckd_calloc(nMfccDim1, sizeof(int));
	getpitch(pitch0, benchBuf, benchLength);
	getpitch(pitch1, sampleBuf, sampleLength);

	// VAD processing
	int nStFrame0 = 0, nEdFrame0 = nMfccDim0 - 1;
	int nStFrame1 = 0, nEdFrame1 = nMfccDim1 - 1;
	
	float e1 = removeNoise(benchBuf, benchLength, &nStFrame0, &nEdFrame0);
	float e2 = removeNoise(sampleBuf, sampleLength, &nStFrame1, &nEdFrame1);

	if (e2+30 < e1) {
		printf("\n");
		printf("\tVAD process(samples):\n");
		printf("\t\t standard: [%d, %d] => [%d, %d]\n", 0, benchLength, mfc2frame(nStFrame0), mfc2frame(nEdFrame0));
		printf("\te1=%.3f, e2=%.3f\n", e1, e2);
		printf("\n\tscore: %d%%\n", 0);

		ckd_free_2d(mfccMat0);
		ckd_free_2d(mfccMat1);
		ckd_free(pitch0);
		ckd_free(pitch1);

		return 0;
	}

	if (nStFrame0 >= nEdFrame0) {
		nStFrame0 = 0, nEdFrame0 = nMfccDim0 - 1;
	}
	if (nStFrame1 >= nEdFrame1) {
		nStFrame1 = 0, nEdFrame1 = nMfccDim1 - 1;
	}
	
	// remove noise at start and end
	for (i = 0, j = nStFrame0; j < nEdFrame0; i++, j++) {
		pitch0[i] = pitch0[j];
		for (k = 0; k < FEAT_NUM; k++)
			mfccMat0[i][k] = mfccMat0[j][k];
	}
	nMfccDim0 = nEdFrame0 - nStFrame0;

	for (i = 0, j = nStFrame1; j < nEdFrame1; i++, j++) {
		pitch1[i] = pitch1[j];
		for (k = 0; k < FEAT_NUM; k++)
			mfccMat1[i][k] = mfccMat1[j][k];
	}
	nMfccDim1 = nEdFrame1 - nStFrame1;
	
	printf("\n");
	printf("\tVAD process(samples):\n");
	printf("\t\t standard: [%d, %d] => [%d, %d]\n", 0, benchLength, mfc2frame(nStFrame0), mfc2frame(nEdFrame0));
	printf("\t\t testing : [%d, %d] => [%d, %d]\n", 0, sampleLength, mfc2frame(nStFrame1), mfc2frame(nEdFrame1));

	// prediction
	int pred = getSvmPredict(mfccMat0, nMfccDim0, mfccMat1, nMfccDim1, pitch0, pitch1, 200);
	
	ckd_free_2d(mfccMat0);
	ckd_free_2d(mfccMat1);
	ckd_free(pitch0);
	ckd_free(pitch1);
	return pred;
}
