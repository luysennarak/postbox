/*
 * vector
 *
 *  Created on: Mar 15, 2018
 *      Author: Ting
 */

#ifndef SRC_VECTOR_
#define SRC_VECTOR_

typedef struct _FILE_NAME {
	char fname[128];
} fileName;

#define VECTOR_INIT_CAPACITY 4

#define VECTOR_INIT(vec) vector vec; vector_init(&vec)
#define VECTOR_ADD(vec, item) vector_add(&vec, (void *) item)
#define VECTOR_SET(vec, id, item) vector_set(&vec, id, (void *) item)
#define VECTOR_GET(vec, type, id) (type) vector_get(&vec, id)
#define VECTOR_DELETE(vec, id) vector_delete(&vec, id)
#define VECTOR_TOTAL(vec) vector_total(&vec)
#define VECTOR_FREE(vec) vector_free(&vec)

typedef struct mvector {
    void **items;
    int capacity;
    int total;
} mvector;

void vector_init(mvector *);
int vector_total(mvector *);
static void vector_resize(mvector *, int);
void vector_add(mvector *, void *);
void vector_set(mvector *, int, void *);
void *vector_get(mvector *, int);
void vector_delete(mvector *, int);
void vector_free(mvector *);


////////////////////////////////////////////////////
//	mvector v;
//	vector_init(&v);
//
//	vector_add(&v, "Bonjour");
//	vector_add(&v, "tout");
//	vector_add(&v, "le");
//	vector_add(&v, "monde");
//
//	for (i = 0; i < vector_total(&v); i++)
//	   printf("%s ", (char *) vector_get(&v, i));
//	printf("\n");
//
//	vector_delete(&v, 3);
//	vector_delete(&v, 2);
//	vector_delete(&v, 1);
//
//	vector_set(&v, 0, "Hello");
//	vector_add(&v, "World");
//
//	for (i = 0; i < vector_total(&v); i++)
//	   printf("%s ", (char *) vector_get(&v, i));
//	printf("\n");
//
//	vector_free(&v);
///////////////////////////////////////////////////////////////////


#endif /* SRC_VECTOR_ */
