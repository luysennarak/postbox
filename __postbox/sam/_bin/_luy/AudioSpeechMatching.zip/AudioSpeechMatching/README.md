Audio Speech Matching Software Usage
====================================

	This is audio speech matching with evaluating pronunciation.
	Matching engine is provided as type of library	and also there is a test program, named "AudioSpeechMatching".
	It includes training, matching, testing.
	
-	Test program is ran in terminal by next command:	
	  ________________________________________________________________________
	 |																          |
	 |	./bin/AudioSpeechMatching      ./test/standard.wav  ./test/input.wav  |
	 |________________________________________________________________________|	
	 
	Then, result of matching is putout as follows:
		Read benchmark wave file with 12539 samples.
		Read sample wave file with 13746 samples.

				VAD process(samples):
						 Benchmark: [0, 12539] => [1760, 7840]
						 Sample   : [0, 13746] => [3840, 9120]
				Feature extraction:
						 dist([path] - [incline]): -2.213960
						 dist([InvPath] - [Path]): 1.374030
						 diff(SSM [ben] - [samp]): -0.383024
						 Kurtosis: 24.867237

				score: 0.93		 Result:    Best!
				 
	Here, the type of all audio file should be 16KHz, 16bit, mono.
	And voting values are likelihood probability to standard wave file. 
	
	If commands are wrong, usage will help you.
		USAGE: 
		  ______________________________________________________________
		 |																|
		 |	AudioSpeechMatching  [options] [wave file   wave file]      |
		 |______________________________________________________________|	
		 
		 Option
		 wave1 wave2      output matching result of wave1 and wave2

		 -test  dir       set directory to test matching
		 -train dir       set directory to train
		 
		 : wave1 - standard wave file
		 : wave2 - wave file to estimate

-  To run program in Ubuntu system, there is a script "run.sh".
	export LD_LIBRARY_PATH=bin
	./bin/AudioSpeechMatching ./data/standard.wav ./data/bad.wav
	
	In terminal, first input command "export LD_LIBRARY_PATH=bin".
	Then, run-command is the same as windows.
		./bin/AudioSpeechMatching ./data/standard.wav ./data/bad.wav
	
	Command should be ran in root directory of program as above.
	
	
-  Users also can use -test option. Consider that: 
		All audio files are named as following rule:
		Standard wave file should be named "...standard.wav".
		And "...-1.wav" or "...-best.wav" for "Best" class and "...-2.wav" or "...-good.wav" for "Good" class, 
		"...-3.wav" or "...-bad.wav" for "Bad" class. 
		All prefix name except above are the same. 
		
		For ex.) Word_01-1.wav  Word_01-2.wav  Word_01-3.wav  Word_01-standard.wav
				 Letter_02-best.wav  Letter_02-good.wav  Letter_02-bad.wav  Letter_02-standard.wav
		
		To test performance of engine, input command in terminal as follows:
			
			./bin/AudioSpeechMatching -test  ../../samples/40sample
			
		Then, it outputs following result.
			
			Accuracy = 82.143 (138/168) (classification)

-  To train model, one can use option -train.
		./bin/AudioSpeechMatching  -train  ../samples
		
		Then, features file 'SVM_data' and models 'SVR', 'SVC' are stored in same directory, and models are copied to bin directory.
		At this time, if old features file is exist, new extracted features are added in the end of that file.
		So, it should be deleted to create new model.
		
		
-  This program is also provided as library. The user interface is written as in "engineInterface.h".
	
		float 	getMatchingResult(short* benchBuf, int benchLength, short* sampleBuf, int sampleLength);
			parameters:
			benchBuf: audio wave buffer to standard file
			benchLength: sample number of benchBuf
			sampleBuf: audio wave buffer to input file to compare
			sampleLength: sample number of sampleBuf
			return score value as 0 ~ 1
			
		int 	makeTrainData(char* dirName);
			dirName: directory including sample wave files
			
		int 	testData(char* dirName);
			dirName: directory including wave files to test

	Usage:
		#include "engineInterface.h"
		
		float sc;
		sc = getMatchingResult(buf1, sample_num1, buf2, sample_num2);
		
		fprintf(stdout, "score: %.1f\n", sc);